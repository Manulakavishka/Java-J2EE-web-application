package com.jiat.webassignment04.web.entity;

public enum Position {
    SELECT,USER,MANAGER,DIRECTOR,VICEDIRECTOR,EXPORT
}
